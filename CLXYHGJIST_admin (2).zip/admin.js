let form = document.getElementById("myForm");
form.addEventListener("submit", function(event) {
    event.preventDefault();
})

let requests = document.getElementById("requests");
requests.onclick() = function() {
    let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
    let options = {
        method: "GET"
    };

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            let {
                search_results
            } = jsonData;
            displayResults(search_results);
        });
}