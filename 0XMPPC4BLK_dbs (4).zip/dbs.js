let place = document.getElementById("button-place")
place.onclick = function() {
    let stock_name = document.getElementById("stock");

    let quantity = document.getElementById("quantity")

    let order_type = document.getElementById("book")

    let date = document.getElementById("checkout-date")


    let data = {
        name: stock_name,
        order_quantity: order_type,
        order_type: order_type,

        status: date,

    };

    let options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer ACCESS-TOKEN"
        },
        body: JSON.stringify(data)
    };

    fetch("http:localhost:3000/user", options)

}